@extends('layouts.appbo')

@section('content')

<div class="container">
    
<div class="container">
    <div class="box" style="border: none;">
        <img style="width: 90%;" src="{{ asset('img/logo.png') }}" alt="">
    </div>
</div>

</div>


@endsection
