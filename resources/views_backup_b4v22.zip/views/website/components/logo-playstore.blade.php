<a href="https://play.google.com/store/apps/details?id=com.malindo.droneapp.booking" target="_blank">
    <img class="logo-brand" src="{{ asset('website/img/playstore.png') }}" alt="">
</a>
