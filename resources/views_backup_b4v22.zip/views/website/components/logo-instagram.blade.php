<a href="https://www.instagram.com/malindo_agrotek_perkasa/?hl=id" target="_blank">
    <img class="logo-brand" src="{{ asset('website/img/brands/instagram.png') }}" alt="">
</a>
