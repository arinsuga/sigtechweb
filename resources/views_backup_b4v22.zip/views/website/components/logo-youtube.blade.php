<a href="https://www.youtube.com/channel/UCl7TTiRqiBKodrWizlbzX3A/" target="_blank">
    <img class="logo-brand" src="{{ asset('website/img/brands/youtube.png') }}" alt="">
</a>
