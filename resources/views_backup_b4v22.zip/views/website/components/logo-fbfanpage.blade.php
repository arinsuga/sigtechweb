<a href="https://www.facebook.com/MALINDO-AGROTEK-PERKASA-1185724191596579/" target="_blank">
    <img class="logo-brand" src="{{ asset('website/img/brands/fbfanpage.png') }}" alt="">
</a>
