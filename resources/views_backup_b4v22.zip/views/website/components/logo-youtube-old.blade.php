<a href="https://www.youtube.com/" target="_blank">
    <img class="logo-brand" src="{{ asset('website/img/brands/youtube.png') }}" alt="">
</a>
