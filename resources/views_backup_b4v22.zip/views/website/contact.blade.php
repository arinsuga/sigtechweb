@extends('layouts.website')

<!-- styles start -->
@section('style')
@endsection
<!-- styles end -->

<!-- js start -->
@section('js')
@endsection
<!-- js end -->

<!-- content start -->
@section('content')

<!-- contact Section Start -->
<section id="contact" class="contact section-content">
@include('website.contact-item')
</section>
<!-- contact Section End -->
@endsection
<!-- content end -->

